import UIKit

var multiplyingOp: () {
    let a = 5
    let b = 7
    let c = a * b
    print("\(c)")
}
multiplyingOp
